from flask import Flask, render_template, request, jsonify
import time
from datetime import datetime

app = Flask(__name__)

# Dictionary to store start times of different tasks
task_timers = {}
times_log = "times.txt"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start_timer', methods=['POST'])
def start_timer():
    task_name = request.json['task']
    current_time = time.time()
    human_readable_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    task_timers[task_name] = {'start_time': current_time, 'start_time_readable': human_readable_time}
    return jsonify({"message": f"Timer started for {task_name}", "start_time": human_readable_time})

@app.route('/stop_timer', methods=['POST'])
def stop_timer():
    task_name = request.json['task']
    if task_name in task_timers:
        current_time = time.time()
        start_time_data = task_timers.pop(task_name)
        elapsed_time = current_time - start_time_data['start_time']
        stop_time_readable = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(times_log, 'a') as f:
            f.write(f"Task: {task_name}\n")
            f.write(f" Start Time: {start_time_data['start_time_readable']}\n")
            f.write(f" Stop Time: {stop_time_readable}\n")
            f.write(f" Elapsed Time: {elapsed_time:.2f} seconds\n")
            f.write("-" * 40 + "\n")
        return jsonify({"message": f"Timer stopped for {task_name}", "start_time": start_time_data['start_time_readable'], "stop_time": stop_time_readable, "time": f"{elapsed_time:.2f} seconds"})
    else:
        return jsonify({"error": "No active timer for this task"}), 400

@app.route('/sort_times', methods=['POST'])
def sort_times():
    with open(times_log, 'r') as file:
        lines = file.readlines()

    # Extract the task entries
    task_entries = []
    current_entry = []
    total_time_section = False
    for line in lines:
        if line.strip() == '-' * 40:
            if current_entry:  # Avoid adding empty entries
                task_entries.append(current_entry)
            current_entry = []
        elif "Total Time for Each Task" in line:
            total_time_section = True
        elif not total_time_section:
            current_entry.append(line.strip())

    # Process any remaining entries after the last separator
    if current_entry:
        task_entries.append(current_entry)

    # Dictionary to store total time for each task
    task_times = {}

    # Calculate total time for each task
    for entry in task_entries:
        if len(entry) < 4:  # Skip incomplete entries
            continue
        task_name_line = entry[0]
        elapsed_time_line = entry[3]
        if ": " in task_name_line and ": " in elapsed_time_line:
            task_name = task_name_line.split(": ")[1]
            elapsed_time = float(elapsed_time_line.split(": ")[1].split()[0])
            if task_name in task_times:
                task_times[task_name] += elapsed_time
            else:
                task_times[task_name] = elapsed_time

    # Sort the task entries by task name
    sorted_entries = sorted(task_entries, key=lambda entry: entry[0])

    # Write the sorted entries and total times back to the file
    with open(times_log, 'w') as file:
        for entry in sorted_entries:
            for line in entry:
                file.write(line + '\n')
            file.write('-' * 40 + '\n')
        
        # Write the total times for each task
        file.write("\nTotal Time for Each Task:\n")
        for task, total_time in task_times.items():
            file.write(f"{task}: {total_time:.2f} seconds\n")

    return jsonify({"message": "Times sorted and total times calculated successfully"})

if __name__ == '__main__':
    app.run(debug=True)
